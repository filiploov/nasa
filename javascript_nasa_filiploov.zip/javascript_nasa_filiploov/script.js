//API KEY: dPmByoqrNrqLMkbbLdQXz0xnrMXnSmBRZzUVhglY
let apiSpaceRef = "https://api.nasa.gov/mars-photos/api/v1/rovers/curiosity/photos?earth_date=2015-2-3&api_key=dPmByoqrNrqLMkbbLdQXz0xnrMXnSmBRZzUVhglY"

//Skapa Ref till HTML taggar
let switchBtn = document.querySelector("#switchBtn");
let bodyRef = document.querySelector("body");
let aliasInput = document.querySelector("#aliasName");
let sendBtn = document.querySelector("#sendBtn");
let h2Ref = document.querySelector("h2");
let containerRef = document.querySelector(".cards-container");

//Lyssna efter när användaren skriver i rutan
aliasInput.addEventListener("keyup", function(){
    //Varje gång användaren släppen en tagent händer detta
    let aliasLength = aliasInput.value.length;
    if(aliasLength > 2){
        //När aliasLength är större än 3 sker detta
        console.log("Nu är det mer än 3 tecken");
        //När input har fler än 3 tecken ska Btn bli enabled
        sendBtn.disabled = false;
    }else{
        console.log("Det är mindre än 3 tecken");
        //När input har mindre än 3 tecken ska Btn bli disenabled
        sendBtn.disabled = true;
    }
})

//När aliasInput är i focus gör detta
aliasInput.addEventListener("focus", function(){
    //Vad ska hända när aliasInput är i focus
    console.log("Du ställde dig i textrutan");
    aliasInput.classList.toggle("bgBorder");
})
//Motsattsen till focus är blur
aliasInput.addEventListener("blur", function(){
    //Vad ska hända när vi inte står i rutan
    console.log("Du lämnade rutan");
    aliasInput.classList.toggle("bgBorder");
})

sendBtn.addEventListener("click", function(event){
    //Vad ska hända när vi klickar på sendBtn
    event.preventDefault();
    h2Ref.innerHTML = "Welcome " + aliasInput.value + "!";
    let aliasCheck = aliasInput.value = "";
    if(aliasCheck === ""){
        sendBtn.disabled = true;
    }
})

//Hämtar data från Nasa API
fetch(apiSpaceRef)
.then(response => response.json())
.then(data => {
 //kontrollera om de finns något i results array
    if(data.photos.length === 0){
        console.log("de finns ingen data från Nasa!")
    }else{
        for (let i = 0; i < data.photos.length; i++) {
            console.log("hej från bilder");
            containerRef.innerHTML += "<article class='card'><h4>"+data.photos[i].earth_date+"</h4><div class='nasa-pic'><img src='"+data.photos[i].img_src+"'></div></article>"; 
        }
    }
})
//Hämtar upp evetuella fel
.catch(error => console.log ("detta är fel: " + error));

//När jag clickar på switch ska dark class läggas till på body
switchBtn.addEventListener("click", function(){
    console.log("Toggle körs");
    bodyRef.classList.toggle("dark");
});